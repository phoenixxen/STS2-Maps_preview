# Map Preview（杀戮尖塔 2）

正式版 `1.0.0`，适配本机已核验的测试版 `v0.111.0`（2026-08-13）。这是**零额外依赖**版本；地图打开后会在右下角创建一个独立的青绿色 **查看地图** 按钮。

按钮尺寸、位置和青绿色配色与“检查点历史”接近，但不依赖或复制任何其他 Mod 控件。点击后会等比缩放并居中整张地图，使横向、纵向的所有路线节点都能在同一屏显示；再点一次 **返回正常地图** 即可恢复原来的拖拽地图。预览状态会临时禁用原地图拖拽和滚动，防止视图意外偏移。按住鼠标右键拖动即可调整按钮位置（不保存位置）。

预览状态也支持原版画线和擦除：笔迹会按缩略图坐标落在正确位置，并与普通地图共用同一份原版绘制数据；返回普通地图后可继续查看和编辑。

## 安装

1. 退出游戏。
2. 在 PowerShell 中执行：

   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\install.ps1
   ```

3. 启动游戏，在 Mod 列表中启用 **Map Preview**。

如果游戏不在 `E:\SteamLibrary\steamapps\common\Slay the Spire 2`，请传入实际目录：

```powershell
.\install.ps1 -GamePath 'D:\SteamLibrary\steamapps\common\Slay the Spire 2'
```

## 实现说明

- 通过原生 `ModInitializer` 和 Harmony 在 `NMapScreen.Open` 后插入按钮。
- 使用高层 `CanvasLayer` 创建独立 UI，因此不会受到地图裁剪、其他 Mod 控件类型或加载顺序影响。
- 同步缩放原版的背景、路线、节点和标记地图层，并排除父子重复缩放。
- 在原版画线的创建、更新和保存阶段换算预览鼠标坐标，保证缩略图与普通地图使用同一份路线数据。
- Mod 不修改地图生成、路径、奖励或存档，清单中标记为 `affects_gameplay: false`。
